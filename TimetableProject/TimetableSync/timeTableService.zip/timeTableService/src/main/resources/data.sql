insert into user(first_name,last_name,password,group_code,index,port)
values('Slobodan','Nikolic','koki6690','304', 'RN107-2017',0);
insert into user(first_name,last_name,password,group_code,index,port)
values('Jovana','Nikolic','koki6690','304','RN108-2017',0);
insert into admin(first_name,last_name,password,username)
values('Jovana','Nikolic','koki6690','Bobica');
insert into admin(first_name,last_name,password,username)
values('Slobodan','Nikolic','koki6690','Shlijani');